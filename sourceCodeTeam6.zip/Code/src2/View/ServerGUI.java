package View;

import javax.swing.JOptionPane;

public class ServerGUI {

	public static void showServerIP(String string) {
		JOptionPane.showMessageDialog(null, "Server IP: " + string);	
	}
}
