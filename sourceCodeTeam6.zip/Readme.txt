To Run the Client/Server.

Run the Server.jar file, it will run in the background so it won't be visible.
Make note of the IP address of the device that is running the server.

Run Client.jar and when prompted input the IP address of the server.

Server.jar and Client.jar do not fully work

Run ServerHotseat.jar to test our code in hotseat mode.